# JobFlow Lanka — Editable Project Copy

This archive contains the editable JobFlow Lanka source code.

## Included
- React/Vite frontend
- Express/tRPC backend
- Drizzle schema and database migrations
- AI job extraction and English/Sinhala/Tamil translation support
- Admin/employer/worker role workflows
- Analytics, WhatsApp contact/share flows, and regression tests

## Local setup
1. Install Node.js 22+ and pnpm.
2. Run `pnpm install`.
3. Provide the project environment variables used by the Manus WebDev template, including `DATABASE_URL`, `JWT_SECRET`, OAuth values, and built-in LLM API values. Do not commit `.env` files or secrets.
4. Run `pnpm check`.
5. Run `pnpm test`.
6. Run `pnpm dev`.

The database migration `drizzle/0007_polite_thor.sql` adds the persisted Sinhala and Tamil translation fields. Apply the migrations to a database you control before starting the server.

## GitHub
To continue development from another GitHub account, create a private repository, copy the extracted files into it, then run:

```bash
git init
git add .
git commit -m "Import JobFlow Lanka"
git branch -M main
git remote add origin https://github.com/YOUR-ACCOUNT/YOUR-REPOSITORY.git
git push -u origin main
```

Never share or commit production credentials, database passwords, OAuth secrets, or API keys.
