import fs from "node:fs";
const path = "/home/ubuntu/jobflow-lanka/client/src/pages/Home.tsx";
let s = fs.readFileSync(path, "utf8");
const old = 'href={`https://wa.me/${normalizeSriLankanPhone(job.contactPhone)}`}';
const replacement = 'href={`https://wa.me/${normalizeSriLankanPhone(job.contactPhone)}?text=${encodeURIComponent(buildJobInterestMessage(job))}`}';
if (!s.includes(old)) throw new Error("WhatsApp href not found");
s = s.replace(old, replacement);
fs.writeFileSync(path, s);
