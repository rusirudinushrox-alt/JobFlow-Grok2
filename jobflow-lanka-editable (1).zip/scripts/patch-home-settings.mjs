import fs from "node:fs";
const path = "/home/ubuntu/jobflow-lanka/client/src/pages/Home.tsx";
let s = fs.readFileSync(path, "utf8");
s = s.replace('<span className="block text-[15px] font-extrabold tracking-tight">JobFlow</span><span className="block text-[10px] font-bold uppercase tracking-[.22em] text-[#7b8d83]">Lanka</span>', '<span className="block text-[15px] font-extrabold tracking-tight">{publicSettings.data?.siteName || "JobFlow Lanka"}</span>');
s = s.replace('<main id="top">', '<main id="top">{publicSettings.data?.announcement && <div className="border-b border-[#dbe8a1] bg-[#f8fbdc] px-5 py-2 text-center text-xs font-bold text-[#52631f]">{publicSettings.data.announcement}</div>}');
s = s.replace('<span className="font-extrabold text-[#496656]">JobFlow Lanka</span>', '<span className="font-extrabold text-[#496656]">{publicSettings.data?.siteName || "JobFlow Lanka"}</span>');
fs.writeFileSync(path, s);
