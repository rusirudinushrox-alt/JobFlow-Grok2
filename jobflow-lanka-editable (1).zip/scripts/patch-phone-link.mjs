import fs from "node:fs";
const path = "/home/ubuntu/jobflow-lanka/client/src/pages/Home.tsx";
let source = fs.readFileSync(path, "utf8");
const importLine = 'import { normalizeSriLankanPhone } from "@shared/types";';
if (!source.includes(importLine)) {
  source = source.replace('import { ArrowUpRight, BriefcaseBusiness, Check, ChevronRight, Clock3, Globe2, Inbox, Languages, MapPin, Menu, MessageCircle, Phone, Plus, Search, Send, Sparkles, Users, X } from "lucide-react";', 'import { ArrowUpRight, BriefcaseBusiness, Check, ChevronRight, Clock3, Globe2, Inbox, Languages, MapPin, Menu, MessageCircle, Phone, Plus, Search, Send, Sparkles, Users, X } from "lucide-react";\n' + importLine);
}
source = source.replace('job.contactPhone.replace(/\\D/g, "")', 'normalizeSriLankanPhone(job.contactPhone)');
fs.writeFileSync(path, source);
