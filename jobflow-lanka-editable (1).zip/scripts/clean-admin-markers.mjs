import fs from "node:fs";
const path = "/home/ubuntu/jobflow-lanka/client/src/pages/AdminDashboard.tsx";
const source = fs.readFileSync(path, "utf8").replace(/^\+/gm, "");
fs.writeFileSync(path, source);
