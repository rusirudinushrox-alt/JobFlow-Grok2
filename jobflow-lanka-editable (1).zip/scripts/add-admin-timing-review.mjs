import fs from "node:fs";
const path = "/home/ubuntu/jobflow-lanka/client/src/pages/AdminDashboard.tsx";
let s = fs.readFileSync(path, "utf8");
const marker = '</p>{job.employmentType === "part-time" && job.immediateHiring && <p className="mt-1 inline-flex items-center gap-1 text-[11px] font-black text-[#4d8b58]"><Radio size={12} />Hiring now</p>}';
const replacement = '</p>{job.employmentType === "part-time" && job.immediateHiring && <p className="mt-1 inline-flex items-center gap-1 text-[11px] font-black text-[#4d8b58]"><Radio size={12} />Hiring now</p>}{job.needsTimingReview && <p className="mt-1 inline-flex items-center gap-1 text-[11px] font-black text-[#b84b4b]"><span className="h-2 w-2 rounded-full bg-[#d05a5a]" />Check time</p>}';
if (!s.includes(marker)) throw new Error("admin timing review insertion point not found");
s = s.replace(marker, replacement);
fs.writeFileSync(path, s);
