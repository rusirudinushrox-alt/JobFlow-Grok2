import fs from "node:fs";
const path = "/home/ubuntu/jobflow-lanka/client/src/pages/Home.tsx";
let s = fs.readFileSync(path, "utf8");
const old = '</span>{job.contactPhone ?';
const next = '</span>{(user?.role === "admin" || job.postedBy === user?.id) && <button onClick={(event) => { event.stopPropagation(); deleteJob(job.id); }} disabled={deleteMutation.isPending} className="inline-flex items-center gap-1 rounded-full bg-[#fff0f0] px-2.5 py-2 text-[11px] font-extrabold text-[#b84b4b] transition hover:bg-[#ffe0e0]" title="Permanently delete job"><Trash2 size={12} />Delete</button>}{job.contactPhone ?';
if (!s.includes(old)) throw new Error("job footer insertion point not found");
s = s.replace(old, next);
fs.writeFileSync(path, s);
