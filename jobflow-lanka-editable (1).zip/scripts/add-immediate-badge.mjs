import fs from "node:fs";
const path = "/home/ubuntu/jobflow-lanka/client/src/pages/Home.tsx";
let s = fs.readFileSync(path, "utf8");
const marker = '</span>{job.paymentAmount &&';
const badge = '</span>{job.employmentType === "part-time" && job.immediateHiring && <span className="inline-flex items-center gap-1.5 rounded-full border border-[#9eb854] bg-[#f4f9ca] px-2.5 py-1 text-[11px] font-black text-[#315d4e] shadow-[0_0_0_3px_rgba(217,233,123,.22)]"><span className="relative flex h-2 w-2"><span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#6bb974] opacity-75" /><span className="relative inline-flex h-2 w-2 rounded-full bg-[#4d9d5b]" /></span><Radio size={12} />Hiring now</span>}{job.paymentAmount &&';
if (!s.includes(marker)) throw new Error("job metadata insertion point not found");
s = s.replace(marker, badge);
fs.writeFileSync(path, s);
