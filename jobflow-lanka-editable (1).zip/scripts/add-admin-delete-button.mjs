import fs from "node:fs";
const path = "/home/ubuntu/jobflow-lanka/client/src/pages/AdminDashboard.tsx";
let s = fs.readFileSync(path, "utf8");
const old = '</SelectContent></Select></div>)}</div></section>}';
const next = '</SelectContent></Select><Button onClick={() => { if (window.confirm("Permanently delete this job? It will not appear on JobFlow again.")) deleteJob.mutate({ id: job.id }); }} disabled={deleteJob.isPending} variant="outline" className="h-9 rounded-full border-[#f0caca] px-3 text-xs font-bold text-[#b84b4b] hover:bg-[#fff0f0]"><Trash2 size={13} />Delete permanently</Button></div>)}</div></section>}';
if (!s.includes(old)) throw new Error("admin job row insertion point not found");
s = s.replace(old, next);
fs.writeFileSync(path, s);
