import fs from "node:fs";
const path = "/home/ubuntu/jobflow-lanka/client/src/pages/Home.tsx";
let s = fs.readFileSync(path, "utf8");
const marker = '</span>}{job.paymentAmount &&';
const notice = '</span>}{(user?.role === "admin" || job.postedBy === user?.id) && job.needsTimingReview && <span className="inline-flex items-center gap-1 rounded-full border border-[#e5a0a0] bg-[#fff0f0] px-2.5 py-1 text-[11px] font-black text-[#b84b4b]" title="Check the work date and time"><span className="h-2 w-2 rounded-full bg-[#d05a5a]" />Check time</span>}{job.paymentAmount &&';
if (!s.includes(marker)) throw new Error("timing review insertion point not found");
s = s.replace(marker, notice);
fs.writeFileSync(path, s);
