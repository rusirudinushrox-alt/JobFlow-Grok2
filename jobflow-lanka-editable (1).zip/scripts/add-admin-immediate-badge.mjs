import fs from "node:fs";
const path = "/home/ubuntu/jobflow-lanka/client/src/pages/AdminDashboard.tsx";
let s = fs.readFileSync(path, "utf8");
const marker = '</p><p className="mt-1 text-xs text-[#829189]">{[job.city, job.district, job.jobType].filter(Boolean).join(" · ") || "Uncategorized"}</p>';
const replacement = '</p>{job.employmentType === "part-time" && job.immediateHiring && <p className="mt-1 inline-flex items-center gap-1 text-[11px] font-black text-[#4d8b58]"><Radio size={12} />Hiring now</p>}<p className="mt-1 text-xs text-[#829189]">{[job.city, job.district, job.jobType].filter(Boolean).join(" · ") || "Uncategorized"}</p>';
if (!s.includes(marker)) throw new Error("admin job metadata marker not found");
s = s.replace(marker, replacement);
fs.writeFileSync(path, s);
