import { and, desc, eq, like, or, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { AnalyticsEvent, InsertJob, InsertUser, analyticsEvents, jobs, siteSettings, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;
export async function getDb() { if (!_db && process.env.DATABASE_URL) { try { _db = drizzle(process.env.DATABASE_URL); } catch (error) { console.warn("[Database] Failed to connect:", error); _db = null; } } return _db; }

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert"); const db = await getDb(); if (!db) return;
  const values: InsertUser = { openId: user.openId }; const updateSet: Record<string, unknown> = {};
  for (const field of ["name", "email", "loginMethod"] as const) { if (user[field] !== undefined) { values[field] = user[field] ?? null; updateSet[field] = user[field] ?? null; } }
  if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
  if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; } else if (user.openId === ENV.ownerOpenId) { values.role = "admin"; updateSet.role = "admin"; values.employerApproved = true; updateSet.employerApproved = true; }
  if (user.employerApproved !== undefined) { values.employerApproved = user.employerApproved; updateSet.employerApproved = user.employerApproved; }
  values.lastSignedIn ??= new Date(); if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date(); await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}
export async function getUserByOpenId(openId: string) { const db = await getDb(); if (!db) return undefined; const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1); return result[0]; }
export type JobFilters = { search?: string; district?: string; city?: string; jobType?: string; employmentType?: string; status?: string };
export async function listJobs(filters: JobFilters = {}) { const db = await getDb(); if (!db) return []; const clauses = []; if (filters.district && filters.district !== "all") clauses.push(eq(jobs.district, filters.district)); if (filters.city && filters.city !== "all") clauses.push(eq(jobs.city, filters.city)); if (filters.jobType && filters.jobType !== "all") clauses.push(eq(jobs.jobType, filters.jobType)); if (filters.employmentType && filters.employmentType !== "all") clauses.push(eq(jobs.employmentType, filters.employmentType as any)); if (filters.status && filters.status !== "all") clauses.push(eq(jobs.status, filters.status as any)); if (filters.search?.trim()) { const term = `%${filters.search.trim()}%`; clauses.push(or(like(jobs.title, term), like(jobs.description, term), like(jobs.city, term), like(jobs.jobType, term))); } return db.select().from(jobs).where(clauses.length ? and(...clauses) : undefined).orderBy(desc(jobs.createdAt)).limit(100); }
export async function createJob(job: InsertJob) { const db = await getDb(); if (!db) throw new Error("Database is not available"); const result = await db.insert(jobs).values(job); const id = Number(result[0].insertId); const created = await db.select().from(jobs).where(eq(jobs.id, id)).limit(1); return created[0]; }
export async function getJobById(id: number) { const db = await getDb(); if (!db) return undefined; const rows = await db.select().from(jobs).where(eq(jobs.id, id)).limit(1); return rows[0]; }
export async function deleteJob(id: number) { const db = await getDb(); if (!db) throw new Error("Database is not available"); await db.delete(analyticsEvents).where(eq(analyticsEvents.jobId, id)); await db.delete(jobs).where(eq(jobs.id, id)); return { success: true as const, id }; }
export async function updateJobStatus(id: number, status: InsertJob["status"]) { const db = await getDb(); if (!db) throw new Error("Database is not available"); await db.update(jobs).set({ status, updatedAt: new Date() }).where(eq(jobs.id, id)); const updated = await db.select().from(jobs).where(eq(jobs.id, id)).limit(1); return updated[0]; }
export async function getJobStats() { const db = await getDb(); if (!db) return { total: 0, active: 0, today: 0, districts: 0 }; const rows = await db.select({ status: jobs.status, district: jobs.district, createdAt: jobs.createdAt }).from(jobs).limit(1000); const today = new Date().toDateString(); return { total: rows.length, active: rows.filter((row) => ["new", "reviewed", "contacted"].includes(row.status)).length, today: rows.filter((row) => new Date(row.createdAt).toDateString() === today).length, districts: new Set(rows.map((row) => row.district).filter(Boolean)).size }; }

export async function recordAnalyticsEvent(event: Omit<AnalyticsEvent, "id" | "createdAt">) { const db = await getDb(); if (!db) return; await db.insert(analyticsEvents).values(event); }
export async function getSiteSettings() { const db = await getDb(); if (!db) return { id: 1, siteName: "JobFlow Lanka", heroTitle: null, heroDescription: null, announcement: null, updatedAt: new Date() }; const rows = await db.select().from(siteSettings).where(eq(siteSettings.id, 1)).limit(1); return rows[0] ?? { id: 1, siteName: "JobFlow Lanka", heroTitle: null, heroDescription: null, announcement: null, updatedAt: new Date() }; }
export async function updateSiteSettings(values: Partial<Omit<typeof siteSettings.$inferInsert, "id">>) { const db = await getDb(); if (!db) throw new Error("Database is not available"); await db.insert(siteSettings).values({ id: 1, ...values }).onDuplicateKeyUpdate({ set: { ...values, updatedAt: new Date() } }); return getSiteSettings(); }

export async function getActivitySummary() {
  const db = await getDb(); if (!db) return { totals: { jobViews: 0, whatsappClicks: 0, searches: 0, employerConversions: 0, featuredViews: 0 }, topJobs: [], topSearches: [], districtDemand: [], recent: [] };
  const events = await db.select().from(analyticsEvents).orderBy(desc(analyticsEvents.createdAt)).limit(5000);
  const count = (type: string) => events.filter((e) => e.eventType === type).length;
  const group = (items: string[]) => Object.entries(items.reduce<Record<string, number>>((acc, item) => { if (item) acc[item] = (acc[item] || 0) + 1; return acc; }, {})).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([label, value]) => ({ label, value }));
  const jobIds = group(events.filter((e) => e.eventType === "job_view" && e.jobId).map((e) => String(e.jobId)));
  const jobRows = jobIds.length ? await db.select({ id: jobs.id, title: jobs.title }).from(jobs).where(or(...jobIds.map((j) => eq(jobs.id, Number(j.label))))) : [];
  return { totals: { jobViews: count("job_view"), whatsappClicks: count("whatsapp_click"), searches: count("search"), employerConversions: count("employer_conversion"), featuredViews: count("featured_job_view") }, topJobs: jobIds.map((item) => ({ ...item, title: jobRows.find((j) => j.id === Number(item.label))?.title || `Job #${item.label}` })), topSearches: group(events.filter((e) => e.eventType === "search").map((e) => e.searchTerm || "(empty)")), districtDemand: group(events.map((e) => e.district || "Unknown")), recent: events.slice(0, 15).map((e) => ({ eventType: e.eventType, jobId: e.jobId, searchTerm: e.searchTerm, district: e.district, createdAt: e.createdAt })) };
}
