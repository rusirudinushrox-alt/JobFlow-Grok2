import { describe, expect, it } from "vitest";
import { appRouter, hasImmediateHiringSignal, isImmediateTimingMatch } from "./routers";
import type { TrpcContext } from "./_core/context";
import { buildJobInterestMessage, buildJobShareMessage, getLocalizedJobDescription, getLocalizedJobTitle, normalizeSriLankanPhone } from "@shared/types";

function publicContext(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

function authContext(id = 1): TrpcContext {
  return {
    user: {
      id,
      openId: "jobflow-test-user",
      email: "test@example.com",
      name: "Test User",
      loginMethod: "manus",
      role: "user",
      employerApproved: false,
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("jobs router", () => {
  it("normalizes Sri Lankan phone numbers for WhatsApp links", () => {
    expect(normalizeSriLankanPhone("0772991879")).toBe("94772991879");
    expect(normalizeSriLankanPhone("+94 77 299 1879")).toBe("94772991879");
    expect(normalizeSriLankanPhone("0094772991879")).toBe("94772991879");
  });

  it("builds a WhatsApp reply that identifies the exact job", () => {
    const message = buildJobInterestMessage({ id: 42, title: "Kitchen assistant", city: "Galle", district: "Galle", paymentAmount: 2800, paymentType: "day" });
    expect(message).toContain("Kitchen assistant");
    expect(message).toContain("Job #42");
    expect(message).toContain("Galle");
    expect(message).toContain("Rs. 2,800 / day");
  });

  it("builds a complete share message with the original post text", () => {
    const message = buildJobShareMessage({ id: 7, title: "Driver needed", sourceText: "Original WhatsApp post with all details", city: "Kandy", district: "Kandy", paymentAmount: 5000, paymentType: "day", workDate: "Today", workTime: "9 AM" });
    expect(message).toContain("Job #7");
    expect(message).toContain("Location: Kandy · Kandy");
    expect(message).toContain("Payment: Rs. 5,000 / day");
    expect(message).toContain("Original WhatsApp post with all details");
  });

  it("detects immediate worker-needed language without false positives for ordinary timing", () => {
    expect(hasImmediateHiringSignal("Dan enna worker kenek oone, immediate", null, null)).toBe(true);
    expect(hasImmediateHiringSignal("Worker needed for next Monday", "next Monday", null)).toBe(false);
    expect(isImmediateTimingMatch("immediate", "today", "now")).toBe(true);
    expect(isImmediateTimingMatch("immediate", "tomorrow", "now")).toBe(false);
    expect(isImmediateTimingMatch("immediate", null, null)).toBe(false);
  });

  it("returns a public job feed with the expected record shape", async () => {
    const caller = appRouter.createCaller(publicContext());
    const result = await caller.jobs.list({ search: "", district: "all", jobType: "all", status: "all" });
    expect(Array.isArray(result)).toBe(true);
    if (result.length > 0) {
      expect(result[0]).toMatchObject({ id: expect.any(Number), title: expect.any(String), sourceText: expect.any(String) });
      expect(result[0]).toHaveProperty("titleSinhala");
      expect(result[0]).toHaveProperty("titleTamil");
      expect(result[0]).toHaveProperty("descriptionSinhala");
      expect(result[0]).toHaveProperty("descriptionTamil");
    }
  });

  it("shows the persisted job translation for the selected language and falls back safely", () => {
    const job = {
      title: "Kitchen assistant",
      description: "Work in a hotel kitchen",
      titleSinhala: "මුළුතැන්ගෙයි සහායක",
      titleTamil: "சமையலறை உதவியாளர்",
      descriptionSinhala: "හෝටල් මුළුතැන්ගෙයක වැඩ",
      descriptionTamil: "ஹோட்டல் சமையலறையில் வேலை",
    };
    expect(getLocalizedJobTitle(job, "en")).toBe("Kitchen assistant");
    expect(getLocalizedJobTitle(job, "si")).toBe("මුළුතැන්ගෙයි සහායක");
    expect(getLocalizedJobTitle(job, "ta")).toBe("சமையலறை உதவியாளர்");
    expect(getLocalizedJobDescription(job, "si")).toBe("හෝටල් මුළුතැන්ගෙයක වැඩ");
    expect(getLocalizedJobDescription(job, "ta")).toBe("ஹோட்டல் சமையலறையில் வேலை");
    expect(getLocalizedJobTitle({ title: "Legacy job", titleSinhala: null, titleTamil: null }, "si")).toBe("Legacy job");
  });

  it("blocks a normal worker from publishing a job", async () => {
    const caller = appRouter.createCaller(authContext());
    await expect(caller.jobs.createFromMessage({ rawText: "short", employmentType: "full-time" })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("does not allow a non-owner worker to delete another user's job", async () => {
    const caller = appRouter.createCaller(authContext(999999));
    const jobs = await appRouter.createCaller(publicContext()).jobs.list({ search: "", district: "all", jobType: "all", status: "all" });
    const foreignJob = jobs.find((job) => job.postedBy !== 999999);
    if (foreignJob) {
      await expect(caller.jobs.delete({ id: foreignJob.id })).rejects.toMatchObject({ code: "FORBIDDEN" });
      await expect(caller.jobs.updateStatus({ id: foreignJob.id, status: "closed" })).rejects.toMatchObject({ code: "FORBIDDEN" });
    }
    await expect(caller.jobs.delete({ id: 999999999 })).rejects.toMatchObject({ code: "NOT_FOUND" });
  });

  it("does not allow a public visitor to delete any job", async () => {
    const caller = appRouter.createCaller(publicContext());
    await expect(caller.jobs.delete({ id: 1 })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("protects the owner activity summary from normal users", async () => {
    const caller = appRouter.createCaller(authContext());
    await expect(caller.admin.summary()).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("accepts only known analytics event types", async () => {
    const caller = appRouter.createCaller(publicContext());
    await expect(caller.analytics.track({ eventType: "not-a-real-event" as never })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });
});
