import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { invokeLLM } from "./_core/llm";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, employerProcedure, publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { createJob, deleteJob, getActivitySummary, getJobById, getJobStats, getSiteSettings, listJobs, recordAnalyticsEvent, updateJobStatus, updateSiteSettings } from "./db";
import { listEmployerCandidates, setEmployerApproval } from "./employer-access";
import { normalizeSriLankanPhone } from "@shared/types";

const nullableString = { type: ["string", "null"] } as const;

const extractionSchema = {
  type: "object",
  properties: {
    title: { type: "string" },
    description: { type: "string" },
    titleSinhala: { type: "string" },
    titleTamil: { type: "string" },
    descriptionSinhala: { type: "string" },
    descriptionTamil: { type: "string" },
    language: { type: "string" },
    district: nullableString,
    city: nullableString,
    jobType: nullableString,
    skills: nullableString,
    paymentAmount: { type: ["integer", "null"] },
    paymentType: nullableString,
    workDate: nullableString,
    workTime: nullableString,
    contactName: nullableString,
    contactPhone: nullableString,
    confidence: { type: "integer" },
  },
  required: ["title", "description", "titleSinhala", "titleTamil", "descriptionSinhala", "descriptionTamil", "language", "district", "city", "jobType", "skills", "paymentAmount", "paymentType", "workDate", "workTime", "contactName", "contactPhone", "confidence"],
  additionalProperties: false,
} as const;

export function hasImmediateHiringSignal(sourceText: string, workDate?: string | null, workTime?: string | null) {
  const normalized = `${sourceText} ${workDate ?? ""} ${workTime ?? ""}`.toLocaleLowerCase().replace(/[.,!?/\\-]/g, " ");
  return /(dan\s+enna|den\s+enna|danma|dæn|immediate(?:ly)?|right\s+now|start\s+now|come\s+now|need\s+now|asap|urgent|today|now|දැන්|වහාම|இப்போ|உடனடி)/i.test(normalized);
}

function sriLankaClock() {
  const parts = new Intl.DateTimeFormat("en-GB", { timeZone: "Asia/Colombo", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).formatToParts(new Date());
  const get = (type: string) => Number(parts.find((part) => part.type === type)?.value || 0);
  return { date: `${get("year")}-${String(get("month")).padStart(2, "0")}-${String(get("day")).padStart(2, "0")}`, minutes: get("hour") * 60 + get("minute") };
}

export function isImmediateTimingMatch(sourceText: string, workDate?: string | null, workTime?: string | null) {
  const combined = `${sourceText} ${workDate ?? ""} ${workTime ?? ""}`.toLocaleLowerCase();
  if (/tomorrow|next\s+(?:day|monday|tuesday|wednesday|thursday|friday|saturday|sunday)|හෙට|நாளை/i.test(combined)) return false;
  const clock = sriLankaClock();
  const dateText = (workDate || "").toLocaleLowerCase();
  const today = dateText.includes("today") || dateText.includes("now") || dateText.includes("dan") || dateText.includes("දැන්") || dateText.includes("இன்று") || /^\d{4}-\d{2}-\d{2}$/.test(dateText) && dateText === clock.date;
  if (!today) return false;
  if (!workTime || /now|immediate|dan|දැන්|இப்போ/i.test(workTime)) return true;
  const match = workTime.match(/(\d{1,2})(?::(\d{2}))?\s*(am|pm)?/i);
  if (!match) return false;
  let hour = Number(match[1]); const minute = Number(match[2] || 0); const meridiem = match[3]?.toLowerCase();
  if (meridiem === "pm" && hour < 12) hour += 12;
  if (meridiem === "am" && hour === 12) hour = 0;
  const start = hour * 60 + minute;
  const endMatch = workTime.slice((match.index || 0) + match[0].length).match(/(\d{1,2})(?::(\d{2}))?\s*(am|pm)?/i);
  if (endMatch) {
    let endHour = Number(endMatch[1]); const endMinute = Number(endMatch[2] || 0); const endMeridiem = endMatch[3]?.toLowerCase();
    if (endMeridiem === "pm" && endHour < 12) endHour += 12;
    if (endMeridiem === "am" && endHour === 12) endHour = 0;
    const end = endHour * 60 + endMinute;
    if (clock.minutes >= start && clock.minutes <= end) return true;
  }
  return start >= clock.minutes - 90 && start <= clock.minutes + 180;
}

async function extractJobDetails(sourceText: string) {
  const response = await invokeLLM({
    model: "gpt-5-mini",
    messages: [
      {
        role: "system",
        content: `You extract Sri Lankan job leads from WhatsApp messages. The input may be Sinhala, English, Tamil, Roman Sinhala, or mixed. Return only the requested JSON. Preserve the original meaning. Create a clear English title and description, then translate the same job accurately into Sinhala and Tamil in titleSinhala/titleTamil/descriptionSinhala/descriptionTamil. Do not transliterate: use natural Sinhala and Tamil scripts. Keep phone numbers, payment amounts, dates, times, place names, company names, and proper nouns accurate; do not invent missing details. Normalize district and city names to common English spellings where clear. paymentAmount should be a number only when an amount is clearly present. confidence is 0-100. If the message is not a job lead, still create short text in all three languages and set confidence below 30.`,
      },
      { role: "user", content: sourceText },
    ],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "job_lead_extraction",
        strict: true,
        schema: extractionSchema,
      },
    },
  });
  const content = response.choices[0]?.message?.content;
  const raw = typeof content === "string" ? content : "{}";
  try {
    const parsed = JSON.parse(raw);
    return {
      title: String(parsed.title || "Untitled job lead").slice(0, 255),
      description: String(parsed.description || sourceText).slice(0, 5000),
      titleSinhala: String(parsed.titleSinhala || parsed.title || "රැකියා අවස්ථාව").slice(0, 255),
      titleTamil: String(parsed.titleTamil || parsed.title || "வேலை வாய்ப்பு").slice(0, 255),
      descriptionSinhala: String(parsed.descriptionSinhala || parsed.description || sourceText).slice(0, 5000),
      descriptionTamil: String(parsed.descriptionTamil || parsed.description || sourceText).slice(0, 5000),
      language: String(parsed.language || "mixed").slice(0, 32),
      district: parsed.district ? String(parsed.district).slice(0, 120) : null,
      city: parsed.city ? String(parsed.city).slice(0, 120) : null,
      jobType: parsed.jobType ? String(parsed.jobType).slice(0, 160) : null,
      skills: parsed.skills ? String(parsed.skills).slice(0, 2000) : null,
      paymentAmount: typeof parsed.paymentAmount === "number" ? Math.round(parsed.paymentAmount) : null,
      paymentType: parsed.paymentType ? String(parsed.paymentType).slice(0, 80) : null,
      workDate: parsed.workDate ? String(parsed.workDate).slice(0, 120) : null,
      workTime: parsed.workTime ? String(parsed.workTime).slice(0, 120) : null,
      contactName: parsed.contactName ? String(parsed.contactName).slice(0, 160) : null,
      contactPhone: normalizeSriLankanPhone(parsed.contactPhone ? String(parsed.contactPhone).slice(0, 64) : null),
      confidence: Math.max(0, Math.min(100, Number(parsed.confidence) || 0)),
    };
  } catch {
    return {
      title: "Needs review",
      description: sourceText.slice(0, 5000),
      titleSinhala: "පරීක්ෂා කිරීම අවශ්‍යයි",
      titleTamil: "மதிப்பாய்வு தேவை",
      descriptionSinhala: sourceText.slice(0, 5000),
      descriptionTamil: sourceText.slice(0, 5000),
      language: "mixed",
      district: null,
      city: null,
      jobType: null,
      skills: null,
      paymentAmount: null,
      paymentType: null,
      workDate: null,
      workTime: null,
      contactName: null,
      contactPhone: null,
      confidence: 0,
    };
  }
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  jobs: router({
    list: publicProcedure.input(z.object({
      search: z.string().optional(),
      district: z.string().optional(),
      city: z.string().optional(),
      jobType: z.string().optional(),
      employmentType: z.string().optional(),
      status: z.string().optional(),
    }).optional()).query(({ input }) => listJobs(input ?? {})),
    stats: publicProcedure.query(() => getJobStats()),
    createFromMessage: employerProcedure.input(z.object({ rawText: z.string().min(8).max(10000), employmentType: z.enum(["part-time", "full-time"]) })).mutation(async ({ input, ctx }) => {
      const extracted = await extractJobDetails(input.rawText);
      const immediateSignal = hasImmediateHiringSignal(input.rawText, extracted.workDate, extracted.workTime);
      const timingMatches = isImmediateTimingMatch(input.rawText, extracted.workDate, extracted.workTime);
      return createJob({ ...extracted, employmentType: input.employmentType, immediateHiring: input.employmentType === "part-time" && immediateSignal && timingMatches, needsTimingReview: input.employmentType === "part-time" && immediateSignal && !timingMatches, sourceText: input.rawText, postedBy: ctx.user.id });
    }),
    updateStatus: protectedProcedure.input(z.object({ id: z.number().int().positive(), status: z.enum(["new", "reviewed", "contacted", "closed", "rejected"]) })).mutation(async ({ input, ctx }) => {
      const job = await getJobById(input.id);
      if (!job) throw new TRPCError({ code: "NOT_FOUND", message: "Job was not found." });
      if (ctx.user.role !== "admin" && job.postedBy !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN", message: "Only the job poster or admin can change this job status." });
      return updateJobStatus(input.id, input.status);
    }),
    delete: protectedProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ input, ctx }) => {
      const job = await getJobById(input.id);
      if (!job) throw new TRPCError({ code: "NOT_FOUND", message: "Job was not found." });
      const isOwner = typeof job.postedBy === "number" && job.postedBy === ctx.user.id;
      if (ctx.user.role !== "admin" && !isOwner) throw new TRPCError({ code: "FORBIDDEN", message: "Only the original job poster can delete this job. Admins can delete any job." });
      return deleteJob(input.id);
    }),
  }),
  analytics: router({
    track: publicProcedure.input(z.object({ eventType: z.enum(["job_view", "whatsapp_click", "search", "district_view", "featured_job_view", "employer_conversion"]), jobId: z.number().int().positive().optional(), searchTerm: z.string().max(255).optional(), district: z.string().max(120).optional(), metadata: z.string().max(1000).optional() })).mutation(({ input, ctx }) => recordAnalyticsEvent({ eventType: input.eventType, jobId: input.jobId ?? null, searchTerm: input.searchTerm ?? null, district: input.district ?? null, metadata: input.metadata ?? null, userId: ctx.user?.id ?? null })),
  }),
  publicSettings: publicProcedure.query(() => getSiteSettings()),
  admin: router({
    summary: adminProcedure.query(() => getActivitySummary()),
    settings: adminProcedure.query(() => getSiteSettings()),
    saveSettings: adminProcedure.input(z.object({ siteName: z.string().min(2).max(160), heroTitle: z.string().max(255).optional(), heroDescription: z.string().max(2000).optional(), announcement: z.string().max(255).optional() })).mutation(({ input }) => updateSiteSettings(input)),
    jobs: adminProcedure.input(z.object({ status: z.string().optional(), employmentType: z.string().optional() }).optional()).query(({ input }) => listJobs({ status: input?.status, employmentType: input?.employmentType })),
    updateJobStatus: adminProcedure.input(z.object({ id: z.number().int().positive(), status: z.enum(["new", "reviewed", "contacted", "closed", "rejected"]) })).mutation(({ input }) => updateJobStatus(input.id, input.status)),
    employerCandidates: adminProcedure.query(() => listEmployerCandidates()),
    setEmployerApproval: adminProcedure.input(z.object({ userId: z.number().int().positive(), approved: z.boolean() })).mutation(({ input }) => setEmployerApproval(input.userId, input.approved)),
  }),
});

export type AppRouter = typeof appRouter;
