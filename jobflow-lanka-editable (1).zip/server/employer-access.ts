import { desc, eq, ne } from "drizzle-orm";
import { getDb } from "./db";
import { users } from "../drizzle/schema";

export async function listEmployerCandidates() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(users).where(ne(users.role, "admin")).orderBy(desc(users.createdAt)).limit(200);
}

export async function setEmployerApproval(userId: number, approved: boolean) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(users).set({ role: approved ? "employer" : "user", employerApproved: approved, updatedAt: new Date() }).where(eq(users.id, userId));
  const rows = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  return rows[0];
}
