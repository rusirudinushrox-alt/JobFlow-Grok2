/**
 * Unified type exports
 * Import shared types from this single entry point.
 */

export type * from "../drizzle/schema";
export * from "./_core/errors";

export type JobLanguage = "en" | "si" | "ta";

export function getLocalizedJobTitle(job: { title: string; titleSinhala?: string | null; titleTamil?: string | null }, language: JobLanguage): string {
  if (language === "si") return job.titleSinhala || job.title;
  if (language === "ta") return job.titleTamil || job.title;
  return job.title;
}

export function getLocalizedJobDescription(job: { description: string; descriptionSinhala?: string | null; descriptionTamil?: string | null }, language: JobLanguage): string {
  if (language === "si") return job.descriptionSinhala || job.description;
  if (language === "ta") return job.descriptionTamil || job.description;
  return job.description;
}

/** Normalize common Sri Lankan phone formats for wa.me links. */
export function normalizeSriLankanPhone(value: string | null | undefined): string | null {
  if (!value) return null;
  const compact = value.trim().replace(/[\s().-]/g, "");
  if (compact.startsWith("+94")) return compact.slice(1).replace(/\D/g, "");
  if (compact.startsWith("0094")) return compact.slice(2).replace(/\D/g, "");
  const digits = compact.replace(/\D/g, "");
  if (/^0\d{9}$/.test(digits)) return `94${digits.slice(1)}`;
  if (/^94\d{9}$/.test(digits)) return digits;
  return digits || null;
}

/** Create a pre-filled WhatsApp reply so employers know exactly which job the worker means. */
export function buildJobInterestMessage(job: { id: number; title: string; city?: string | null; district?: string | null; paymentAmount?: number | null; paymentType?: string | null }): string {
  const location = [job.city, job.district].filter(Boolean).join(", ") || "Sri Lanka";
  const payment = job.paymentAmount ? ` Payment: Rs. ${job.paymentAmount.toLocaleString()}${job.paymentType ? ` / ${job.paymentType}` : ""}.` : "";
  return `Hi, I am interested in the job “${job.title}” (Job #${job.id}) in ${location}.${payment} Is this position still available?`;
}

/** Create a complete plain-text job post for sharing to any app or chat. */
export function buildJobShareMessage(job: { id: number; title: string; sourceText: string; city?: string | null; district?: string | null; paymentAmount?: number | null; paymentType?: string | null; workDate?: string | null; workTime?: string | null }): string {
  const location = [job.city, job.district].filter(Boolean).join(" · ") || "Sri Lanka";
  const payment = job.paymentAmount ? `Rs. ${job.paymentAmount.toLocaleString()}${job.paymentType ? ` / ${job.paymentType}` : ""}` : "Not specified";
  const timing = [job.workDate, job.workTime].filter(Boolean).join(" · ") || "Not specified";
  return `JobFlow Lanka — Job #${job.id}\n${job.title}\nLocation: ${location}\nPayment: ${payment}\nTime: ${timing}\n\n${job.sourceText}`;
}
