ALTER TABLE `users` MODIFY COLUMN `role` enum('user','employer','admin') NOT NULL DEFAULT 'user';--> statement-breakpoint
ALTER TABLE `users` ADD `employerApproved` boolean DEFAULT false NOT NULL;