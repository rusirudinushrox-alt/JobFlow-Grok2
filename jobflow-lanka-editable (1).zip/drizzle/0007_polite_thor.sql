ALTER TABLE `jobs` ADD `titleSinhala` varchar(255);--> statement-breakpoint
ALTER TABLE `jobs` ADD `titleTamil` varchar(255);--> statement-breakpoint
ALTER TABLE `jobs` ADD `descriptionSinhala` text;--> statement-breakpoint
ALTER TABLE `jobs` ADD `descriptionTamil` text;