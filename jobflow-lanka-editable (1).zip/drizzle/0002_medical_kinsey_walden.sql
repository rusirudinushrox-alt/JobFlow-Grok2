CREATE TABLE `analyticsEvents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`eventType` varchar(48) NOT NULL,
	`jobId` int,
	`userId` int,
	`searchTerm` varchar(255),
	`district` varchar(120),
	`metadata` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `analyticsEvents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `siteSettings` (
	`id` int NOT NULL DEFAULT 1,
	`siteName` varchar(160) NOT NULL DEFAULT 'JobFlow Lanka',
	`heroTitle` varchar(255),
	`heroDescription` text,
	`announcement` varchar(255),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `siteSettings_id` PRIMARY KEY(`id`)
);
