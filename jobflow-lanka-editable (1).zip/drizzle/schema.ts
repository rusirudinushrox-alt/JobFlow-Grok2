import { boolean, int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "employer", "admin"]).default("user").notNull(),
  employerApproved: boolean("employerApproved").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const jobs = mysqlTable("jobs", {
  id: int("id").autoincrement().primaryKey(),
  sourceText: text("sourceText").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description").notNull(),
  titleSinhala: varchar("titleSinhala", { length: 255 }),
  titleTamil: varchar("titleTamil", { length: 255 }),
  descriptionSinhala: text("descriptionSinhala"),
  descriptionTamil: text("descriptionTamil"),
  language: varchar("language", { length: 32 }).notNull().default("mixed"),
  district: varchar("district", { length: 120 }),
  city: varchar("city", { length: 120 }),
  jobType: varchar("jobType", { length: 160 }),
  employmentType: mysqlEnum("employmentType", ["part-time", "full-time"]).notNull().default("part-time"),
  immediateHiring: boolean("immediateHiring").notNull().default(false),
  needsTimingReview: boolean("needsTimingReview").notNull().default(false),
  skills: text("skills"),
  paymentAmount: int("paymentAmount"),
  paymentType: varchar("paymentType", { length: 80 }),
  workDate: varchar("workDate", { length: 120 }),
  workTime: varchar("workTime", { length: 120 }),
  contactName: varchar("contactName", { length: 160 }),
  contactPhone: varchar("contactPhone", { length: 64 }),
  confidence: int("confidence").notNull().default(0),
  status: mysqlEnum("status", ["new", "reviewed", "contacted", "closed", "rejected"]).notNull().default("new"),
  postedBy: int("postedBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const analyticsEvents = mysqlTable("analyticsEvents", {
  id: int("id").autoincrement().primaryKey(),
  eventType: varchar("eventType", { length: 48 }).notNull(),
  jobId: int("jobId"),
  userId: int("userId"),
  searchTerm: varchar("searchTerm", { length: 255 }),
  district: varchar("district", { length: 120 }),
  metadata: text("metadata"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const siteSettings = mysqlTable("siteSettings", {
  id: int("id").primaryKey().default(1),
  siteName: varchar("siteName", { length: 160 }).notNull().default("JobFlow Lanka"),
  heroTitle: varchar("heroTitle", { length: 255 }),
  heroDescription: text("heroDescription"),
  announcement: varchar("announcement", { length: 255 }),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Job = typeof jobs.$inferSelect;
export type InsertJob = typeof jobs.$inferInsert;
export type AnalyticsEvent = typeof analyticsEvents.$inferSelect;
export type SiteSettings = typeof siteSettings.$inferSelect;
export const jobStatuses = ["new", "reviewed", "contacted", "closed", "rejected"] as const;
export type JobStatus = (typeof jobStatuses)[number];
